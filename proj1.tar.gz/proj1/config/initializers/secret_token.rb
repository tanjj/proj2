# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Proj1::Application.config.secret_token = '4443278b21df7d62d20edf29b4375c3fda3313526bc0ac8fff35aafa7182eeea6dec0693f264668fcbf21784a37fac3998cd421c397eb4711a64dc917ee6915a'
