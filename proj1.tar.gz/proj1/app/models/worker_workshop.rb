# app/models/worker_workshop
class WorkerWorkshop < ActiveRecord::Base
   set_table_name "worker_workshop"
end