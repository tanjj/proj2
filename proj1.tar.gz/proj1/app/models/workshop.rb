# app/models/workshop.rb
class Workshop < ActiveRecord::Base
end
