# app/models/worker_workshops
class WorkerWorkshops < ActiveRecord::Base
   set_table_name "worker_workshops_view"
end