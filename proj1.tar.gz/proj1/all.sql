\i init.sql
\i addTestData.sql
\i addFuncs.sql