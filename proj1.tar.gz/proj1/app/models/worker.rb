# app/models/worker.rb
class Worker < ActiveRecord::Base
end
